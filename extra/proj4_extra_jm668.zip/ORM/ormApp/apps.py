from django.apps import AppConfig


class OrmappConfig(AppConfig):
    name = 'ormApp'
